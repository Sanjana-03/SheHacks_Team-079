from django.contrib.auth.models import User
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import Product
from .forms import Signup
from django.contrib.auth import logout,authenticate

# Create your views here.

def index(request):
    return render(request, 'index.html')

def product(request):
    data = Product.objects.all()
    return render(request, 'product.html', {'data':data})

def sellproduct(request):
    form = Product()
    if request.method == 'POST':
        form = Product(request.POST)
        if form.is_valid():
            form.save()
            return redirect('sellproduct')
    context = {'form': form}

    return render(request, 'sellproduct.html', context)

# def register(request):
#
#     if request.method == 'POST':
#         username = request.POST['username']
#         firstname = request.POST['firstname']
#         lastname = request.POST['lastname']
#         mobile = request.POST['mobile']
#         email = request.POST['email']
#         password = request.POST['password']
#
#         # Checks for erronous input
#
#         # Create The User
#
#         myuser = User.objects.create_user(username, email, password)
#         myuser.firstname = firstname
#         myuser.lastname = lastname
#         myuser.mobile = mobile
#         myuser.save()
#         messages.success(request, "Your Account is Created")
#
#         return redirect('MainHome')
#
#     else:
#         return HttpResponse('Page Not Found')

def register(request):
    form = Signup()
    if request.method == 'POST':
        form = Signup(request.POST)
        if form.is_valid():
            form.save()
            return redirect('register')
    context = {'form': form}
    return render(request, 'register.html', context)


def login(request):
    if request.user.is_authenticated:
        return redirect('MainHome')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = Signup.objects.filter(username=username, password=password)
        if len(user):
            return redirect('register')
        else:
            messages.error(request, "Invalid username or password.")

    return render(request, 'register.html')



def postservices(request):
    return render(request, 'postservices.html')

def blog(request):
    return render(request, 'blog.html')

def chatbot(request):
    return render(request, 'chatbot.html')

def services(request):
    return render(request, 'services.html')

def payment(request):
    return render(request, 'payment.html')

def blog1(request):
    return render(request, '1.html')

def blog2(request):
    return render(request, '2.html')

def blog3(request):
    return render(request, '3.html')

def blog4(request):
    return render(request, '4.html')

def blog5(request):
    return render(request, '5.html')