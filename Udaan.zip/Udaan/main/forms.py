# from django.forms import ModelForm
#
# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User
# from django import forms
#
#
#
# #from .models import Order
#
# #class OrderForm(ModelForm):
#     #class Meta:
#         #model = Order
#         #fields = '__all__'
#
# class SignUpForm(UserCreationForm):
#     firstname = forms.CharField(max_length=100)
#     lastname = forms.CharField(max_length=100)
#     mobile = forms.CharField(max_length=10)
#     #email = forms.EmailField(max_length=254, help_text='Required. Inform a valid email address.')
#     #password = forms.CharField(widget=PasswordInput)
#     class Meta:
#         model = User
#         fields = ['firstname', 'lastname','mobile', 'email', 'password']

from django.forms import ModelForm
from django import forms
from .models import *

class Signup(forms.ModelForm):
    class Meta:
        model=Signup
        fields = '__all__'

class Product(forms.ModelForm):
    class Meta:
        model= Product
        fields = '__all__'