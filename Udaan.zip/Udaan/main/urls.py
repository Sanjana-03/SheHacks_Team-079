from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="MainHome" ),
    path('product/', views.product, name="Product"),
    path('sellproduct/', views.sellproduct, name="SellProduct"),
    path('register/', views.register, name="register"),
    path('register/', views.login, name="login"),
    path('postservices/', views.postservices, name="PostServices"),
    path('blog/', views.blog, name="Blog"),
    path('chatbot/', views.chatbot, name="Chatbot"),
    path('services/', views.services, name="View Services"),
    path('product/payment/', views.payment, name="Payment"),
    path('blog/1/', views.blog1, name="Blog1"),
    path('blog/2/', views.blog2, name="Blog2"),
    path('blog/3/', views.blog3, name="Blog3"),
    path('blog/4/', views.blog4, name="Blog3"),
    path('blog/5/', views.blog5, name="Blog3")

]