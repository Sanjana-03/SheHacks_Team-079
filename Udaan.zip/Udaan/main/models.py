from django.db import models


# Create your models here.
class Signup(models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=66)
    firstname = models.CharField(max_length=66)
    lastname = models.CharField(max_length=66)
    mobile = models.IntegerField(max_length=66)
    email = models.EmailField(max_length=66)
    password = models.CharField(max_length=66)


    def __str__(self):
        return self.firstname


# Create your models here.
class Product(models.Model):
    product_id = models.AutoField
    product_name = models.CharField(max_length=50)
    category = models.CharField(max_length=50, default="")
    seller = models.CharField(max_length=50, default="")
    price = models.IntegerField(default=0)
    desc = models.CharField(max_length=1500)
    image = models.ImageField(upload_to="images", default="")


    def __str__(self):
        return self.product_name